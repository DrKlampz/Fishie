# Fishie

## [v0.4.14](https://github.com/DrKlampz/Fishie/tree/v0.4.14) (2026-11-17)
[Full Changelog](https://github.com/DrKlampz/Fishie/compare/v0.4.13...v0.4.14) [Previous Releases](https://github.com/DrKlampz/Fishie/releases)

- v0.4.14: choose which mouse button casts and loots  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
